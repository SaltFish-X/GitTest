//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    words: '点按钮让我说话',
    userInfo: {}
  },

  say: function( e ) {
    var hello = require('../../utils/hello.js');
    hello( this );
  },
  onLoad: function () {
  }
})
