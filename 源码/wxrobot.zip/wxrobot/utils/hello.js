// V1 
function hello_v1( page ) {
    page.setData({words:'HELLO WORLD!'});
}

function hello_v2( page ) {

    page.setData({words:'LOADING...'});

    wx.request({
        url: 'http://wwp.appcook.cn/test.php', //仅为示例，并非真实的接口地址
        data: {t:Date.parse(new Date())},
        header: {
            'content-type': 'application/json'
        },
        success: function(res) {
            page.setData({words:res.data});
        }
    })


      
}

module.exports = hello_v2


