<?php

$mysqli = new mysqli("10.66.151.210", "root", "yun123456", "words");

/* check connection */
if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();
}

$query = "SELECT * FROM `hello` ORDER BY RAND() LIMIT 1";
$result = $mysqli->query($query);

/* associative array */
$row = $result->fetch_array(MYSQLI_ASSOC);

echo json_encode(end($row));

/* free result set */
$result->free();

/* close connection */
$mysqli->close();


mysql_close($link);